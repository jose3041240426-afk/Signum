"use client";

interface WordOverlayProps {
  word: string;
  confidence: number;
  visible: boolean;
}

export function WordOverlay({ word, confidence, visible }: WordOverlayProps) {
  if (!visible) return null;
  return (
    <div
      className="absolute left-5 top-5 rounded-2xl border border-orange-300/30 bg-gray-900/90 p-5 text-white backdrop-blur-md"
      style={{ minWidth: 180, transition: "opacity 0.3s, transform 0.3s", opacity: visible ? 1 : 0, transform: visible ? "scale(1)" : "scale(0.95)", pointerEvents: "none" }}
    >
      <div className="mb-1 text-xs font-bold uppercase tracking-widest text-orange-400/60">PALABRA Signum</div>
      <div className="bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-3xl font-black text-transparent drop-shadow-lg">
        {word || "—"}
      </div>
      {word && (
        <div className="mt-2 text-center">
          <span className="text-lg font-bold text-orange-500">{confidence}%</span>
          <span className="ml-1 text-xs text-white/50 uppercase tracking-widest">Certeza</span>
          <div className="mt-1 h-1 w-full rounded-full bg-white/15">
            <div className="h-full rounded-full bg-orange-500" style={{ width: `${confidence}%` }} />
          </div>
        </div>
      )}
    </div>
  );
}
